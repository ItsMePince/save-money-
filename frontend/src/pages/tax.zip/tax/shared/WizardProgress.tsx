import React from "react";

type Props = {
  /** ขั้นปัจจุบัน (เริ่มที่ 1) */
  currentStep: number;
  /** จำนวนขั้นทั้งหมด (ดีฟอลต์ 8) */
  totalSteps?: number;
};

const WizardProgress: React.FC<Props> = ({ currentStep, totalSteps = 8 }) => {
  const steps = Array.from({ length: totalSteps }, (_, i) => i + 1);

  return (
    <div className="wizard-progress">
      {/* เส้นเทาพื้นหลัง */}
      <div className="wizard-line" />

      {/* เส้นสีมิ้นสำหรับช่วงที่ผ่านแล้ว */}
      <div
        className="wizard-line passed"
        style={{
          width: `${((currentStep - 1) / (totalSteps - 1)) * 100}%`,
        }}
      />

      {/* วาดจุดทั้งหมด */}
      {steps.map((num) => {
        let stateClass = "is-disabled";
        if (num < currentStep) stateClass = "is-passed";
        else if (num === currentStep) stateClass = "is-active";

        return (
          <div key={num} className={`wizard-dot ${stateClass}`}>
            {num}
          </div>
        );
      })}
    </div>
  );
};

export default WizardProgress;