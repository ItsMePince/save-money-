import React, { useMemo, useState } from "react";
import "./tax.css";
import WizardProgress from "./shared/WizardProgress";
import IncomeStep from "./steps/01-Income/IncomeStep";

const TOTAL_STEPS = 7;

export default function TaxWizardModal({
  isOpen,
  onClose,
}: {
  isOpen: boolean;
  onClose: () => void;
}) {
  const [step, setStep] = useState(1);
  const [completed, setCompleted] = useState<Record<number, boolean>>({});
  const [income, setIncome] = useState({
    salaryPerMonth: "",
    bonusPerYear: "",
    otherIncomePerYear: "",
  });

  // ✅ เช็กว่า step ไหนกรอกแล้วบ้าง
  const completedArray = Array.from({ length: TOTAL_STEPS }, (_, i) => !!completed[i + 1]);

  // ✅ อนุญาตให้ข้าม step ได้เฉพาะที่กรอกครบแล้ว
  const canJumpToStep = (n: number) => {
    if (n === 1) return true;
    for (let i = 1; i < n; i++) if (!completed[i]) return false;
    return true;
  };

  const goNextFromIncome = () => {
    setCompleted((c) => ({ ...c, 1: true }));
    setStep(2);
  };

  const body = useMemo(() => {
    if (step === 1) {
      return (
        <IncomeStep
          values={income}
          setValues={(patch) => setIncome((v) => ({ ...v, ...patch }))}
          onNext={goNextFromIncome}
        />
      );
    }
    return (
      <div className="card">
        <div className="section-title">หน้านี้ยังไม่ทำ</div>
      </div>
    );
  }, [step, income]);

  if (!isOpen) return null;

  return (
    <div
      className="tax-modal-overlay"
      role="dialog"
      aria-modal="true"
      id="tax-wizard-modal"
    >
      <div className="tax-modal">
        {/* ===== Header ===== */}
        <div className="tax-modal-header">
          <h3 className="tax-title">โปรแกรมคำนวณภาษี</h3>
          <button
            className="tax-close-btn"
            onClick={() => {
              onClose();
              setStep(1);
            }}
          >
            ×
          </button>
        </div>

        {/* ===== แถบขั้นตอน (วงกลม 1–7) ===== */}
        <WizardProgress
          total={TOTAL_STEPS}
          active={step}
          completed={completedArray}
          onClickStep={(n) => canJumpToStep(n) && setStep(n)}
        />

        {/* ===== เนื้อหาแต่ละสเต็ป ===== */}
        <div className="tax-modal-body">{body}</div>
      </div>
    </div>
  );
}